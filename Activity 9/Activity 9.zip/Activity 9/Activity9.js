$(document).ready(function() {

        // get the image URL and id for each image


        // preload the image for each link

        // set up the event handlers for each link


            // cancel the default action of each link


    // move the focus to the second link

}); // end ready